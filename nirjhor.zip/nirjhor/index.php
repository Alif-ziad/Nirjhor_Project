<?php
    header("Location: views/customer/products.php");
    exit();
?>
