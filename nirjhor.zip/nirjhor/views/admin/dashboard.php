<?php
session_start();
?>

<h2>Admin Dashboard</h2>

<a href="approve_products.php">
    <button>Manage Requests</button>
</a>

<a href="manage_users.php">
    <button>Manage Users</button>
</a>
<a href="../auth/logout.php">
    <button>Logout</button>
</a>