<?php
session_start();
session_start();
session_destroy();

header("Location: ../customer/products.php");
exit();
?>