<?php
session_start();
?>

<h2>Seller Dashboard</h2>

<a href="add_product.php">
    <button> Add New product</button>
</a>

<a href="manage_products.php">
    <button>Manage Products</button>
</a>
<a href="../auth/logout.php">
    <button>Logout</button>
</a>