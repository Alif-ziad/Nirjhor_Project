<?php
session_start();
require_once("../models/userModel.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $hasErr = false;
    $idErr = "";
    $passErr = "";

    $id = $_POST["id"] ?? "";
    $name = $_POST['name'];
    $email = $_POST['email'];
    $pass = $_POST["password"] ?? "";
    $role = $_POST['role'];
    $shop_name = $_POST['shop_name'] ?? null;
    $shop_address = $_POST['shop_address'] ?? null;

    /* Empty check */
    if (empty($id) || empty($pass)) {
        $idErr = empty($id) ? "User ID cannot be empty" : "";
        $passErr = empty($pass) ? "Password cannot be empty" : "";

        header("Location: ../views/auth/login.php?idErr=$idErr&passErr=$passErr");
        exit();
    }
    /* REGISTER */
if(isset($_POST['register'])){
    registerUser(
        $name, $email, $password, $role, $shop_name = null, $shop_address = null
       //$_POST['name'],$_POST['email'],$_POST['password'],$_POST['role'],$_POST['shop_name'] ?? null,$_POST['shop_address'] ?? null
    );
    header("Location: ../views/auth/login.php");
    exit();
}

/* LOGIN */
if(isset($_POST['login'])){
    $user = authUser($_POST['email'],$_POST['password']);

    if($user==="NOT_APPROVED"){
        header("Location: ../views/auth/login.php?err=Seller not approved");
        exit();
    }

    if($user){
        $_SESSION['id']=$user['id'];
        $_SESSION['role']=$user['role'];

        header("Location: ../views/{$user['role']}/dashboard.php");
        exit();
    }
    header("Location: ../views/auth/login.php?err=Invalid login");
}

    /* Authenticate */
    $user = authUser($id, $pass);

    if (!$user) {
        header("Location: ../views/auth/login.php?genErr=ID or password didn't match");
        exit();
    }

    /* Seller approval check */
    if ($user['role'] === 'seller' && $user['is_approved'] == 0) {
        header("Location: ../views/auth/login.php?genErr=Seller not approved yet");
        exit();
    }

    /* Login success */
    $_SESSION['id'] = $user['id'];
    $_SESSION['role'] = $user['role'];

    /* Redirect based on role */
    if ($user['role'] === 'admin') {
        header("Location: ../views/admin/dashboard.php");
        exit();
    }

    if ($user['role'] === 'seller') {
        header("Location: ../views/seller/dashboard.php");
        exit();
    }

    if ($user['role'] === 'customer') {
        header("Location: ../views/customer/products.php");
        exit();
    }

}
?>
